// Example data

export enum ShipType {
    Transport,
    Miner,
    Colonizer,
}

export enum MessageType {
    DeployMiner = "deploy-miner",
    ColonizePlanet = "colonize-planet",
}
