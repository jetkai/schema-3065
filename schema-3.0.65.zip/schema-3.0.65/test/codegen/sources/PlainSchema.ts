import * as schema  from "../../../src";

export const Vec3 = schema.schema({
    x: "number",
    y: "number",
    z: "number"
})
