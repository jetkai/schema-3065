npm run generate-test-1 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/PrimitiveTypes
npm run generate-test-2 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/ChildSchemaTypes
npm run generate-test-3 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/ArraySchemaTypes
npm run generate-test-4 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/MapSchemaTypes
npm run generate-test-5 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/InheritedTypes
npm run generate-test-6 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/MapSchemaInt8
npm run generate-test-7 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/BackwardsForwards
npm run generate-test-8 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/FilteredTypes
npm run generate-test-9 -- --csharp --output  ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/InstanceSharingTypes
npm run generate-test-10 -- --csharp --output ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/Callbacks
npm run generate-test-11 -- --csharp --output ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/MapSchemaMoveNullifyType
npm run generate-test-12 -- --csharp --output ../colyseus-unity-sdk/Assets/Colyseus/Tests/Editor/ColyseusTests/Schema/ArraySchemaClear

